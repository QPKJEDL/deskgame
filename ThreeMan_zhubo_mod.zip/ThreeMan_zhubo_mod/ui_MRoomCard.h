/********************************************************************************
** Form generated from reading UI file 'MRoomCard.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MROOMCARD_H
#define UI_MROOMCARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MRoomCard
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QLabel *xian3_result;
    QSpacerItem *horizontalSpacer_2;
    QLabel *xian2_result;
    QSpacerItem *horizontalSpacer_3;
    QLabel *xian1_result;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_xian3;
    QLabel *three_three_pic;
    QLabel *three_two_pic;
    QLabel *three_one_pic;
    QSpacerItem *horizontalSpacer_6;
    QLabel *label_xian2;
    QLabel *two_three_pic;
    QLabel *two_two_pic;
    QLabel *two_one_pic;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_xian1;
    QLabel *one_three_pic;
    QLabel *one_two_pic;
    QLabel *one_one_pic;
    QSpacerItem *horizontalSpacer_8;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_9;
    QLabel *xian1_result_4;
    QSpacerItem *horizontalSpacer_10;
    QLabel *xian1_result_3;
    QSpacerItem *horizontalSpacer_11;
    QLabel *xian1_result_2;
    QSpacerItem *horizontalSpacer_12;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_13;
    QLabel *label_xian1_4;
    QLabel *one_three_pic_5;
    QLabel *one_two_pic_5;
    QLabel *one_one_pic_5;
    QSpacerItem *horizontalSpacer_14;
    QLabel *label_xian1_3;
    QLabel *one_three_pic_4;
    QLabel *one_two_pic_4;
    QLabel *one_one_pic_4;
    QSpacerItem *horizontalSpacer_15;
    QLabel *label_xian1_2;
    QLabel *one_three_pic_3;
    QLabel *one_two_pic_3;
    QLabel *one_one_pic_3;
    QSpacerItem *horizontalSpacer_16;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer_17;
    QLabel *label_zhuang;
    QLabel *zhuang_three_pic;
    QLabel *zhuang_two_pic;
    QLabel *zhuang_one_pic;
    QLabel *zhuang_result;
    QSpacerItem *horizontalSpacer_18;

    void setupUi(QWidget *MRoomCard)
    {
        if (MRoomCard->objectName().isEmpty())
            MRoomCard->setObjectName(QString::fromUtf8("MRoomCard"));
        MRoomCard->resize(1209, 501);
        MRoomCard->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 48, 90);"));
        verticalLayout_2 = new QVBoxLayout(MRoomCard);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        xian3_result = new QLabel(MRoomCard);
        xian3_result->setObjectName(QString::fromUtf8("xian3_result"));
        QFont font;
        font.setPointSize(22);
        xian3_result->setFont(font);
        xian3_result->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        xian3_result->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(xian3_result);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        xian2_result = new QLabel(MRoomCard);
        xian2_result->setObjectName(QString::fromUtf8("xian2_result"));
        xian2_result->setFont(font);
        xian2_result->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        xian2_result->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(xian2_result);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        xian1_result = new QLabel(MRoomCard);
        xian1_result->setObjectName(QString::fromUtf8("xian1_result"));
        xian1_result->setFont(font);
        xian1_result->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        xian1_result->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(xian1_result);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        horizontalLayout_2->setStretch(0, 12);
        horizontalLayout_2->setStretch(1, 6);
        horizontalLayout_2->setStretch(2, 15);
        horizontalLayout_2->setStretch(3, 6);
        horizontalLayout_2->setStretch(4, 14);
        horizontalLayout_2->setStretch(5, 6);
        horizontalLayout_2->setStretch(6, 6);

        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        label_xian3 = new QLabel(MRoomCard);
        label_xian3->setObjectName(QString::fromUtf8("label_xian3"));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        label_xian3->setFont(font1);
        label_xian3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(label_xian3);

        three_three_pic = new QLabel(MRoomCard);
        three_three_pic->setObjectName(QString::fromUtf8("three_three_pic"));
        three_three_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(three_three_pic);

        three_two_pic = new QLabel(MRoomCard);
        three_two_pic->setObjectName(QString::fromUtf8("three_two_pic"));
        three_two_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(three_two_pic);

        three_one_pic = new QLabel(MRoomCard);
        three_one_pic->setObjectName(QString::fromUtf8("three_one_pic"));
        three_one_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(three_one_pic);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);

        label_xian2 = new QLabel(MRoomCard);
        label_xian2->setObjectName(QString::fromUtf8("label_xian2"));
        label_xian2->setFont(font1);
        label_xian2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(label_xian2);

        two_three_pic = new QLabel(MRoomCard);
        two_three_pic->setObjectName(QString::fromUtf8("two_three_pic"));
        two_three_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(two_three_pic);

        two_two_pic = new QLabel(MRoomCard);
        two_two_pic->setObjectName(QString::fromUtf8("two_two_pic"));
        two_two_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(two_two_pic);

        two_one_pic = new QLabel(MRoomCard);
        two_one_pic->setObjectName(QString::fromUtf8("two_one_pic"));
        two_one_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(two_one_pic);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_7);

        label_xian1 = new QLabel(MRoomCard);
        label_xian1->setObjectName(QString::fromUtf8("label_xian1"));
        label_xian1->setFont(font1);
        label_xian1->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(label_xian1);

        one_three_pic = new QLabel(MRoomCard);
        one_three_pic->setObjectName(QString::fromUtf8("one_three_pic"));
        one_three_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(one_three_pic);

        one_two_pic = new QLabel(MRoomCard);
        one_two_pic->setObjectName(QString::fromUtf8("one_two_pic"));
        one_two_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(one_two_pic);

        one_one_pic = new QLabel(MRoomCard);
        one_one_pic->setObjectName(QString::fromUtf8("one_one_pic"));
        one_one_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_3->addWidget(one_one_pic);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_8);

        horizontalLayout_3->setStretch(0, 3);
        horizontalLayout_3->setStretch(1, 4);
        horizontalLayout_3->setStretch(2, 4);
        horizontalLayout_3->setStretch(3, 4);
        horizontalLayout_3->setStretch(4, 4);
        horizontalLayout_3->setStretch(5, 4);
        horizontalLayout_3->setStretch(6, 4);
        horizontalLayout_3->setStretch(7, 4);
        horizontalLayout_3->setStretch(8, 4);
        horizontalLayout_3->setStretch(9, 4);
        horizontalLayout_3->setStretch(10, 4);
        horizontalLayout_3->setStretch(11, 4);
        horizontalLayout_3->setStretch(12, 4);
        horizontalLayout_3->setStretch(13, 4);
        horizontalLayout_3->setStretch(14, 3);

        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_9);

        xian1_result_4 = new QLabel(MRoomCard);
        xian1_result_4->setObjectName(QString::fromUtf8("xian1_result_4"));
        xian1_result_4->setFont(font);
        xian1_result_4->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        xian1_result_4->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(xian1_result_4);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_10);

        xian1_result_3 = new QLabel(MRoomCard);
        xian1_result_3->setObjectName(QString::fromUtf8("xian1_result_3"));
        xian1_result_3->setFont(font);
        xian1_result_3->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        xian1_result_3->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(xian1_result_3);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_11);

        xian1_result_2 = new QLabel(MRoomCard);
        xian1_result_2->setObjectName(QString::fromUtf8("xian1_result_2"));
        xian1_result_2->setFont(font);
        xian1_result_2->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        xian1_result_2->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(xian1_result_2);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_12);

        horizontalLayout_4->setStretch(0, 12);
        horizontalLayout_4->setStretch(1, 6);
        horizontalLayout_4->setStretch(2, 15);
        horizontalLayout_4->setStretch(3, 6);
        horizontalLayout_4->setStretch(4, 14);
        horizontalLayout_4->setStretch(5, 6);
        horizontalLayout_4->setStretch(6, 6);

        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_13);

        label_xian1_4 = new QLabel(MRoomCard);
        label_xian1_4->setObjectName(QString::fromUtf8("label_xian1_4"));
        label_xian1_4->setFont(font1);
        label_xian1_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_5->addWidget(label_xian1_4);

        one_three_pic_5 = new QLabel(MRoomCard);
        one_three_pic_5->setObjectName(QString::fromUtf8("one_three_pic_5"));
        one_three_pic_5->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_three_pic_5);

        one_two_pic_5 = new QLabel(MRoomCard);
        one_two_pic_5->setObjectName(QString::fromUtf8("one_two_pic_5"));
        one_two_pic_5->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_two_pic_5);

        one_one_pic_5 = new QLabel(MRoomCard);
        one_one_pic_5->setObjectName(QString::fromUtf8("one_one_pic_5"));
        one_one_pic_5->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_one_pic_5);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_14);

        label_xian1_3 = new QLabel(MRoomCard);
        label_xian1_3->setObjectName(QString::fromUtf8("label_xian1_3"));
        label_xian1_3->setFont(font1);
        label_xian1_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_5->addWidget(label_xian1_3);

        one_three_pic_4 = new QLabel(MRoomCard);
        one_three_pic_4->setObjectName(QString::fromUtf8("one_three_pic_4"));
        one_three_pic_4->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_three_pic_4);

        one_two_pic_4 = new QLabel(MRoomCard);
        one_two_pic_4->setObjectName(QString::fromUtf8("one_two_pic_4"));
        one_two_pic_4->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_two_pic_4);

        one_one_pic_4 = new QLabel(MRoomCard);
        one_one_pic_4->setObjectName(QString::fromUtf8("one_one_pic_4"));
        one_one_pic_4->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_one_pic_4);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_15);

        label_xian1_2 = new QLabel(MRoomCard);
        label_xian1_2->setObjectName(QString::fromUtf8("label_xian1_2"));
        label_xian1_2->setFont(font1);
        label_xian1_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_5->addWidget(label_xian1_2);

        one_three_pic_3 = new QLabel(MRoomCard);
        one_three_pic_3->setObjectName(QString::fromUtf8("one_three_pic_3"));
        one_three_pic_3->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_three_pic_3);

        one_two_pic_3 = new QLabel(MRoomCard);
        one_two_pic_3->setObjectName(QString::fromUtf8("one_two_pic_3"));
        one_two_pic_3->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_two_pic_3);

        one_one_pic_3 = new QLabel(MRoomCard);
        one_one_pic_3->setObjectName(QString::fromUtf8("one_one_pic_3"));
        one_one_pic_3->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_5->addWidget(one_one_pic_3);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_16);

        horizontalLayout_5->setStretch(0, 3);
        horizontalLayout_5->setStretch(1, 4);
        horizontalLayout_5->setStretch(2, 4);
        horizontalLayout_5->setStretch(3, 4);
        horizontalLayout_5->setStretch(4, 4);
        horizontalLayout_5->setStretch(5, 4);
        horizontalLayout_5->setStretch(6, 4);
        horizontalLayout_5->setStretch(7, 4);
        horizontalLayout_5->setStretch(8, 4);
        horizontalLayout_5->setStretch(9, 4);
        horizontalLayout_5->setStretch(10, 4);
        horizontalLayout_5->setStretch(11, 4);
        horizontalLayout_5->setStretch(12, 4);
        horizontalLayout_5->setStretch(13, 4);
        horizontalLayout_5->setStretch(14, 3);

        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_17);

        label_zhuang = new QLabel(MRoomCard);
        label_zhuang->setObjectName(QString::fromUtf8("label_zhuang"));
        label_zhuang->setFont(font1);
        label_zhuang->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));

        horizontalLayout_7->addWidget(label_zhuang);

        zhuang_three_pic = new QLabel(MRoomCard);
        zhuang_three_pic->setObjectName(QString::fromUtf8("zhuang_three_pic"));
        zhuang_three_pic->setMinimumSize(QSize(88, 120));
        zhuang_three_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_7->addWidget(zhuang_three_pic);

        zhuang_two_pic = new QLabel(MRoomCard);
        zhuang_two_pic->setObjectName(QString::fromUtf8("zhuang_two_pic"));
        zhuang_two_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_7->addWidget(zhuang_two_pic);

        zhuang_one_pic = new QLabel(MRoomCard);
        zhuang_one_pic->setObjectName(QString::fromUtf8("zhuang_one_pic"));
        zhuang_one_pic->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(0, 32, 57);"));

        horizontalLayout_7->addWidget(zhuang_one_pic);

        zhuang_result = new QLabel(MRoomCard);
        zhuang_result->setObjectName(QString::fromUtf8("zhuang_result"));
        zhuang_result->setMinimumSize(QSize(0, 45));
        zhuang_result->setMaximumSize(QSize(91, 32));
        zhuang_result->setFont(font);
        zhuang_result->setStyleSheet(QString::fromUtf8("border-radius:5px;\n"
"background-color: rgb(200, 140, 0);"));
        zhuang_result->setAlignment(Qt::AlignCenter);

        horizontalLayout_7->addWidget(zhuang_result);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_18);

        horizontalLayout_7->setStretch(0, 5);
        horizontalLayout_7->setStretch(1, 1);
        horizontalLayout_7->setStretch(2, 1);
        horizontalLayout_7->setStretch(3, 1);
        horizontalLayout_7->setStretch(4, 1);
        horizontalLayout_7->setStretch(5, 1);
        horizontalLayout_7->setStretch(6, 4);

        verticalLayout->addLayout(horizontalLayout_7);

        verticalLayout->setStretch(0, 1);
        verticalLayout->setStretch(1, 3);
        verticalLayout->setStretch(2, 1);
        verticalLayout->setStretch(3, 3);
        verticalLayout->setStretch(4, 3);

        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(MRoomCard);

        QMetaObject::connectSlotsByName(MRoomCard);
    } // setupUi

    void retranslateUi(QWidget *MRoomCard)
    {
        MRoomCard->setWindowTitle(QCoreApplication::translate("MRoomCard", "Form", nullptr));
        xian3_result->setText(QString());
        xian2_result->setText(QString());
        xian1_result->setText(QString());
        label_xian3->setText(QCoreApplication::translate("MRoomCard", "\351\227\2623", nullptr));
        three_three_pic->setText(QString());
        three_two_pic->setText(QString());
        three_one_pic->setText(QString());
        label_xian2->setText(QCoreApplication::translate("MRoomCard", "\351\227\2622", nullptr));
        two_three_pic->setText(QString());
        two_two_pic->setText(QString());
        two_one_pic->setText(QString());
        label_xian1->setText(QCoreApplication::translate("MRoomCard", "\351\227\2621", nullptr));
        one_three_pic->setText(QString());
        one_two_pic->setText(QString());
        one_one_pic->setText(QString());
        xian1_result_4->setText(QString());
        xian1_result_3->setText(QString());
        xian1_result_2->setText(QString());
        label_xian1_4->setText(QCoreApplication::translate("MRoomCard", "\351\227\2626", nullptr));
        one_three_pic_5->setText(QString());
        one_two_pic_5->setText(QString());
        one_one_pic_5->setText(QString());
        label_xian1_3->setText(QCoreApplication::translate("MRoomCard", "\351\227\2625", nullptr));
        one_three_pic_4->setText(QString());
        one_two_pic_4->setText(QString());
        one_one_pic_4->setText(QString());
        label_xian1_2->setText(QCoreApplication::translate("MRoomCard", "\351\227\2624", nullptr));
        one_three_pic_3->setText(QString());
        one_two_pic_3->setText(QString());
        one_one_pic_3->setText(QString());
        label_zhuang->setText(QCoreApplication::translate("MRoomCard", "\345\272\204\345\256\266", nullptr));
        zhuang_three_pic->setText(QString());
        zhuang_two_pic->setText(QString());
        zhuang_one_pic->setText(QString());
        zhuang_result->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MRoomCard: public Ui_MRoomCard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MROOMCARD_H
