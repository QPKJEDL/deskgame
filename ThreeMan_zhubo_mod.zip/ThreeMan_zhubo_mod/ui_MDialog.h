/********************************************************************************
** Form generated from reading UI file 'MDialog.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MDIALOG_H
#define UI_MDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MDialog
{
public:
    QPushButton *pu_yes;
    QPushButton *pu_no;
    QLabel *label;

    void setupUi(QWidget *MDialog)
    {
        if (MDialog->objectName().isEmpty())
            MDialog->setObjectName(QString::fromUtf8("MDialog"));
        MDialog->resize(400, 300);
        MDialog->setStyleSheet(QString::fromUtf8("background-color: transparent; border-radius: 30px;\n"
""));
        pu_yes = new QPushButton(MDialog);
        pu_yes->setObjectName(QString::fromUtf8("pu_yes"));
        pu_yes->setGeometry(QRect(60, 220, 91, 51));
        pu_yes->setStyleSheet(QString::fromUtf8("QPushButton{color: rgb(255, 255, 255);background:rgb(50, 73, 138);border:1px solid grey; border-radius: 8px;}\n"
"QPushButton:hover{border-color:rgb(139,170,105)}\n"
"QPushButton:pressed{border-color:gray;background-color:rgb(54, 65, 97);}\n"
"QPushButton:disabled{border-color:gray;background-color: rgb(99, 99, 99);\n"
"}"));
        pu_no = new QPushButton(MDialog);
        pu_no->setObjectName(QString::fromUtf8("pu_no"));
        pu_no->setGeometry(QRect(230, 220, 91, 51));
        pu_no->setStyleSheet(QString::fromUtf8("QPushButton{color: rgb(255, 255, 255);background:rgb(50, 73, 138);border:1px solid grey; border-radius: 8px;}\n"
"QPushButton:hover{border-color:rgb(139,170,105)}\n"
"QPushButton:pressed{border-color:gray;background-color:rgb(54, 65, 97);}\n"
"QPushButton:disabled{border-color:gray;background-color: rgb(99, 99, 99);\n"
"}"));
        label = new QLabel(MDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 50, 311, 121));

        retranslateUi(MDialog);

        QMetaObject::connectSlotsByName(MDialog);
    } // setupUi

    void retranslateUi(QWidget *MDialog)
    {
        MDialog->setWindowTitle(QCoreApplication::translate("MDialog", "Form", nullptr));
        pu_yes->setText(QCoreApplication::translate("MDialog", "PushButton", nullptr));
        pu_no->setText(QCoreApplication::translate("MDialog", "PushButton", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MDialog: public Ui_MDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MDIALOG_H
